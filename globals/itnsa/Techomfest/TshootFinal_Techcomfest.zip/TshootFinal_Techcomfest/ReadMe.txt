Format pengumpulan :
File dijadikan rar dengan nama : Network_NamaTim_Tshootfinal.rar